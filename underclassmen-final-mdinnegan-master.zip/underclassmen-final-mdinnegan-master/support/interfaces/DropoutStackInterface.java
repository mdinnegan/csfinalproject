package interfaces;

import structures.StackUnderflowException;

public interface DropoutStackInterface<T> {
	
	public void push(T elem);

	public void resize(int newCapacity);
	
	public T pop() throws StackUnderflowException;

	public T top() throws StackUnderflowException;

	public boolean isEmpty();
	
	public int size();
	
}