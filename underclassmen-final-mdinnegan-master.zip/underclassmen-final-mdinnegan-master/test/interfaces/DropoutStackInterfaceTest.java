package interfaces;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import config.ArrayDropoutStack;
import interfaces.DropoutStackInterface;
import structures.StackUnderflowException;

public class DropoutStackInterfaceTest {
	  
	  private DropoutStackInterface<Integer> stack;
	  
	  @Before
	  public void setup() {
		  
	    stack = new ArrayDropoutStack();
	    
	  }

	  @Test (timeout = 5000)
	  public void testStack() {
		  
		  	assertTrue("Stack should be empty after being constructed.", stack.isEmpty());
	    
	    	stack.push(5);
	    	assertFalse("Stack should not be empty.", stack.isEmpty());
	    	assertEquals("The top element should be 5.", new Integer(5), stack.top());
	    
	    	stack.push(4);
	    	assertEquals("The top element should be 4.", new Integer(4), stack.top());
	    
	    	stack.resize(5);
	    	Integer s = stack.size();
	    	assertEquals("This stack should have a resized capacity of 5.", new Integer(5), s);
	    
	    	Integer t = stack.pop();
	    	assertEquals("The popped element should be 4.", new Integer(4), t);
	    	assertEquals("The top element should be 5.", new Integer(5), stack.top());
	    	assertFalse("The stack should not be empty.", stack.isEmpty());
	    
	    	t = stack.pop();
	    	assertEquals("The popped element should be 5.", new Integer(5), t);
	    	assertTrue("The stack should be empty.", stack.isEmpty());    
	    	
	  }
	  
	  @Test (timeout = 5000, expected = StackUnderflowException.class)
	  public void testStackUnderflowPop() throws StackUnderflowException {
		  
	    stack.pop();
	    
	  }

}