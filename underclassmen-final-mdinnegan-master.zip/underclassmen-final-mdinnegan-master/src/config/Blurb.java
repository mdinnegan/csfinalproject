// generateTestBlurb works for 10000 but not 1 million

package config;

// import java.lang.reflect.Array;
import interfaces.BlurbInterface;

public class Blurb implements BlurbInterface {
	
	String blurb;
	
	String Whoozit = "";
	String Whatzit = "";
	
	public double randomNumber1;
	public double randomNumber2;
	public double randomNumber3;
	
//	char[] characters;
	int length;
	int i;
	
	// generation
	public String generateBlurb() {
		
		generateWhoozit();
		blurb = Whoozit;
		
		generateWhatzit();
		generateMoreWhatzits();
		
		blurb = blurb + Whatzit;
		return blurb;
	
	}
	
	public String generateWhoozit() {
		
		Whoozit = "x";
		generateYs();
		
		return Whoozit;
		
	}
	
	public String generateWhatzit() {
		
		randomNumber1 = Math.round(Math.random());
		
		Whatzit = Whatzit + "q";
		
		if(randomNumber1 == 0) {
			
			Whatzit = Whatzit + "z";
			
		}
		
		else {
			
			Whatzit = Whatzit + "d";
			
		}
		
		generateWhoozit();
		
		Whatzit = Whatzit + Whoozit;
		return Whatzit;
		
	}
	
	public String generateMoreWhatzits() {
		
		randomNumber3 = Math.round(Math.random());
		
		if(randomNumber3 == 0) {
			
			generateWhatzit();
			generateMoreWhatzits();
			
		}
		
		else {
			
		}
		
		return Whatzit;
		
	}
	
	public String generateYs() {
		
		randomNumber2 = Math.round(Math.random());
		
		if(randomNumber2 == 0) {
			
			Whoozit = Whoozit + "y";
			generateYs();
			
		}
		
		else {
			
		}
		
		return Whoozit;
		
	}
	
	
	// verification
	public boolean isBlurb(String blurb) {
		
	    // System.out.println(blurb);
//		characters = blurb.toCharArray();
		length = blurb.length();
		// System.out.println(length);
//		i = 0;
		// System.out.println(i + " " + blurb.charAt(i));
//		int length = blurb.length();
		i = 0;
		if(checkForWhoozit(blurb) == true && checkForWhatzit(blurb) == true) {
			checkForMoreWhatzits(blurb);
			// System.out.println("Final True");
			return true;
//			return isBlurb(blurb);
		}
					
		else {
			return false;
		}
			
//			System.out.println("calling more Whatzits " + i + " " + characters[i] + " " + blurb);

		// checkForWhoozit();
		// checkForWhatzit();
		// checkForMoreWhatzits();
		

		
	}
	//int i=0;
	//int length = blurb.length();

	public boolean checkForWhoozit(String blurb) {
		
//	    int i=0;
//		int length = blurb.length();

//	 System.out.println("i = " + i + " " + blurb.charAt(i));
		
		if(i == length) {
			
			return false;
			
		}
		
		else if(blurb.charAt(i) == 'x') {
			// System.out.println("First x");
			i = i + 1;
			checkForYs(blurb);
			return true;
		
		}
		else {
			// System.out.println("No x " + blurb);
			i = i + 1;
			return false;
		}
			
	}

	public boolean checkForWhatzit(String blurb) {
		
//		int i = 0;
//		int length = blurb.length();
//		char letter = blurb.charAt(i);
		
		if(i == length) {
			
			return false;
			
		}
		
		else if(blurb.charAt(i) == 'q') {
			// System.out.println("calling more Whatzits " + i + " " + blurb.charAt(i) + " " + blurb); 
			i = i + 1;
			if(checkForZDs(blurb) == true && checkForWhoozit(blurb) == true) {
				return true;
			}
			
			else {
				return false;
			}
			
		}
		
		else {
			
			return false;
			
		}
		
	}

	public boolean checkForMoreWhatzits(String blurb) {
		
//		int i = 0;
//		int length = blurb.length();
//		char letter = blurb.charAt(i);
		
		if(i == length) {
			
			return true;
			
		}
		
		else {
			
			if(checkForWhatzit(blurb) == true) {
				// i = i + 1;
				checkForMoreWhatzits(blurb);
				return true;
				
			}
			
			else {
				
				return false;
				
			}
			
		}
		
	}

	public boolean checkForYs(String blurb) {
		
//		int i = 0;
//		int length = blurb.length();
//		char letter = blurb.charAt(i);
		
		if(i == length) {
			
			return true;
			
		}
		
		else if (blurb.charAt(i) == 'y') {
			
			i = i + 1;
			checkForYs(blurb);
			return true;
			
		}
		
		else {

			return true;
			
		}
		
	}

	public boolean checkForZDs(String blurb) {
		
//		int i = 0;
//		int length = blurb.length();
//		char letter = blurb.charAt(i);
		
		if(i == length) {
			
			return false;
			
		}
		
		else if(blurb.charAt(i) == 'z') {
			
			i = i + 1;
			return true;
			
		}
		
		else if(blurb.charAt(i) == 'd') {
			
			i = i + 1;
			return true;
			
		}
		
		else {
			
			return false;
			
		}
		
	}

}
