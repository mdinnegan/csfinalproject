package config;

import structures.StackUnderflowException;
import interfaces.DropoutStackInterface;
import structures.LinearNode;

public class ArrayDropoutStack<T> implements DropoutStackInterface<T>
{

	private final int DEFAULT_CAPACITY = 3;
	
	private int top;
	private int bottom;
	
	private T[] stack;

	public ArrayDropoutStack() {
		
		top = 0;
		bottom = 0;

		stack = (T[])(new Object[DEFAULT_CAPACITY]); 
	
	}

	public ArrayDropoutStack (int initialCapacity) {
		
    	top = 0;
    	bottom = 0;
	
    	stack = ((T[])(new Object[initialCapacity]));
	
	}

	public void push(T element) {

		if (size() == stack.length) {
			
			stack[bottom] = null;
			
		}
		
		top++;
		stack[top] = element;
		
	}
	
	public void resize(int newCapacity) {
		
		if(newCapacity > stack.length) {
			
			// int newObject = newCapacity - stack.length;
			
			// for(int i = 0; i < newObject; i++) {
				
				// int objectPosition = stack.length;
				// T[] biggerStack = (T[])(new Object[objectPosition + 1]);
				// stack = biggerStack;
				
			// }
			
			T[] biggerStack = (T[])(new Object[newCapacity]);
			
			for(int index=0; index < stack.length; index++)
				
				biggerStack[index] = stack[index];
				stack = biggerStack;
		
		
		}
		
		else if(newCapacity < stack.length) {
			
			for(int i = stack.length; i < newCapacity; i--) {
				
				pop();
				
			}
			
		}
			
	}
	
	public T pop() throws StackUnderflowException {
		
		if (isEmpty())
			
			throw new StackUnderflowException("Stack");
			
			T result = stack[top];
			stack[top] = null;
			
			top--;
			
			return result;
			
	}

	public T top() throws StackUnderflowException {
		
		return stack[top];
		
	}

	public boolean isEmpty() {
		
		if(stack[top] == null) {

			return true;
			
		}
		
		else {

			return false;
			
		}
		
	}

	public int size() {

		return stack.length;
		
	}

}