// ran out of time to work in the queues

package config;

import interfaces.CapitalGainsInterface;
import structures.LinearNode;

public class CapitalGains implements CapitalGainsInterface {
	
	int count = 0;
	
	public void buy(int shares, double price) {
		// Queue the share, price, and day groups.
	}
	public double sell(int shares, double price) {
		
		int sellshares = shares;
		double sellprice = price;
		
		int buyshares;
		double buyprice;
		
		if(sellshares == 0) {
			
			return gain;
			
		}
		
		else if(sellshares >= buyshares(i)) { // buyshares of current purchase, i is queue item (which purchase #)
			
			gain = gain + buyshares(i) * (sellprice - buyprice(i));
			sellshares = sellshares - buyshares(i);
			dequeue(i);
			sell(buyshares, buyprice);
			
		}
		
		else {
			
			gain = gain + sellshares * (sellprice - buyprice(i));
			int tempshares = buyshares(i) - sellshares;
			enqueue(tempshares, buyprice(i)); // to a temporary, new queue
			dequeue(i); // out of the old queue
			// loop through entries in original queue to move to the temporary queue, dequeue out of original queue
			// loop through entries moving shares in new queue back to original queue, dequeue out of new queue
			return gain;
			
		}
		
	}

	public int getDay() {

		return 0;
		
	}

}
